const adult = (prefix, botName, ownerName) => {
        return `
「 *${botName}* 」

◪ *INFO*
  ❏ Prefix: 「  ${prefix}  」
  ❏ Creator: ${🔥mateu🔥}
◪ *ABOUT*
  │
  ├─ ❏ ${prefix}info
  ├─ ❏ ${prefix}blocklist
  ├─ ❏ ${prefix}chatlist
  ├─ ❏ ${prefix}ping
  └─ ❏ ${prefix}bugreport
◪ *18+*
  │
  ├─ ❏ ${prefix}toin
  ├─ ❏ ${prefix}hentai
  ├─ ❏ ${prefix}nsfwtrap
  └─ ❏ ${prefix}nsfwneko`
}
exports.adult = adult
