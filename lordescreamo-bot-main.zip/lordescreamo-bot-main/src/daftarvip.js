const daftarvip = (prefix) => { 
	return `
	

*Proprietário do bate-papo BOT :*

_wa.me/15799968046 ou digite *${prefix}dono*

`
}
exports.daftarvip = daftarvip
